from pet import Pet

def main():
    # Create a pet object
    my_pet = Pet()

    # Display the initial status
    my_pet.get_status()

    # Test eating
    my_pet.eat()
    my_pet.get_status()

    # Test sleeping
    my_pet.sleep()
    my_pet.get_status()

    # Test playing
    my_pet.play()
    my_pet.get_status()

    # Teach the pet a new trick
    my_pet.train("Roll over")
    my_pet.show_tricks()

    # Test the pet's status again
    my_pet.get_status()

if __name__ == "__main__":
    main()
