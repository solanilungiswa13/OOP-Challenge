class Pet:
    def __init__(self, name="Dog", hunger=0, energy=10, happiness=5):
        self.name = name
        self.hunger = hunger  # Hunger level (0 = full, 10 = very hungry)
        self.energy = energy  # Energy level (0 = tired, 10 = fully rested)
        self.happiness = happiness  # Happiness level (0–10)
        self.tricks = []  # List to store learned tricks

    def eat(self):
        """Reduces hunger by 3 points and increases happiness by 1."""
        self.hunger = max(0, self.hunger - 3)  # Ensure hunger doesn't go below 0
        self.happiness = min(10, self.happiness + 1)  # Ensure happiness doesn't exceed 10

    def sleep(self):
        """Increases energy by 5 points."""
        self.energy = min(10, self.energy + 5)  # Ensure energy doesn't exceed 10

    def play(self):
        """Decreases energy by 2, increases happiness by 2, and increases hunger by 1."""
        if self.energy >= 2:  # Ensure there's enough energy to play
            self.energy -= 2
            self.happiness = min(10, self.happiness + 2)  # Ensure happiness doesn't exceed 10
            self.hunger = min(10, self.hunger + 1)  # Ensure hunger doesn't exceed 10
        else:
            print(f"{self.name} is too tired to play!")

    def get_status(self):
        """Prints the current state of the pet."""
        status = (f"Name: {self.name}\n"
                  f"Hunger level: {self.hunger}\n"
                  f"Energy level: {self.energy}\n"
                  f"Happiness level: {self.happiness}\n")
        print(status)

    def train(self, trick):
        """Teaches the pet a new trick and stores it in a list."""
        self.tricks.append(trick)
        print(f"{self.name} has learned a new trick: {trick}!")

    def show_tricks(self):
        """Prints all learned tricks."""
        if self.tricks:
            print(f"{self.name} has learned the following tricks: {', '.join(self.tricks)}")
        else:
            print(f"{self.name} hasn't learned any tricks yet.")


# Example usage:
my_pet = Pet()
my_pet.get_status()
my_pet.eat()
my_pet.sleep()
my_pet.play()
my_pet.train("Roll over")
my_pet.show_tricks()
my_pet.get_status()
